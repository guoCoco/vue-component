### 对象组件——indicator

1. name: Indicator

2. 入参和方法
    function
	 (1) open()
	 	 param: 类型object 
	 	 {
	 	 	text:'', // 内容
	 	 }
	 
	 (2) close()
		 手动关闭indicator
3. 使用方式
	Indicator.open({
	 	text: ''
	})
	
	Indicator.close();


4. 期望效果
	样式符合UI图效果
	参数输入有效
	内部方法正确使用

