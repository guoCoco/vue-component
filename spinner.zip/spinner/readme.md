### 基础控件——spinner

1. name: y-spinner

2. 入参和方法
    param: 
	 (1) size ( number类型 正方形边长 单位rem ) 默认为80
	 (2) type ( string类型 动画类型 ) 默认为default 

3. 使用方式
	<y-spinner :size="80"></y-spinner>

4. 期望效果
	样式符合UI图效果
	入参符合效果



